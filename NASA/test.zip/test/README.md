# Generate the Sample Directories
```
dir1/run.sh
dir2/run.sh
```
# Sample Output
When executing ```./sample.sh``` with the correct ```compare.sh```, the output would be like that in ```output/```.

